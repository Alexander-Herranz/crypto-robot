// Importing node modules
//import express from 'express';
const express = require("express")
const app = express();
// Importing source files
const {BittrexAPI} = require("./restClient/BittrexAPI")
var bittrex = new BittrexAPI()

const {Script} = require("./algorithms/Script")
var algorithm = new Script()
//app.use('/', routes);

// arrow functions
const server = app.listen(3000, () => {
	// destructuring
  const {address, port} = server.address();


  // string interpolation:
  console.log(`Example app listening at http://${address}:${port}`);

  //bittrex.getorderbook('btc','ltc','both').then((res)=>{{console.log(res)}})
  //bittrex.getmarkethistory('btc','ltc').then((res)=>{{console.log(res)}})
  //bittrex.getticker('btc','ltc').then((res)=>{{console.log(res)}})


  function start() {
  	algorithm.init()
  }

  let robotinterval = setInterval(start, 3000)


});