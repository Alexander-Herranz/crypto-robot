//exports.Animal = class {
const request = require("request")
const talib = require("talib")
const fs = require('fs');

class Script {

  constructor() {
   this.url = 'https://bittrex.com/api/v1.1/public/'
   this._getMarkets = 'getMarkets'
  }

  doRequest(url) {
     return new Promise(function (resolve, reject) {
       request(url, function (error, res, body) {

         if (!error && res.statusCode == 200) {
           //console.log(body)
           resolve(body);
         } else {
           reject(error);
         }

       });
     }).catch((error) => {
      console.log(url + '--> Request error:');
      console.log(error)
    });
  }

//Bittrex Public API GET requests
  async getmarkets() {
    console.log("request------------>")
    try{
      let endpoint = this.url+this._getMarkets
      console.log(endpoint)
      let res = await this.doRequest(endpoint)
      return res
    } catch(error) {}
  }

  talibtest() {
    try{
      // load the module and display its version
      console.log("TALib Version: " + talib.version);
      let function_desc = talib.explain("ADX");
      console.dir(function_desc);
      // Display all available indicator function names
      let functions = talib.functions;

      let marketContents = fs.readFileSync('examples/marketdata.json','utf8');

      let marketData = JSON.parse(marketContents);
      // execute CDLHAMMER indicator function

      talib.execute({
        name: "ADX",
        startIdx: 0,
        endIdx: 100,
        open: marketData.open,
        high: marketData.high,
        low: marketData.low,
        close: marketData.close,
        optInTimePeriod: 9
      }, function (err, result) {
        //console.log("marketData.close.length: "+marketData.close.length)
      // Show the result array
        console.log("CDLHAMMER Function Results:");
        console.log(result.result.outReal.length);
        console.log(result);

      })



      //console.log(functions)
      /*
      for (i in functions) {
        console.log(functions[i].name);
      }
      */
      //return res




    } catch(error) {}
  }

  init() {
    console.log("start talibtest------------>")
    //try{
      this.talibtest()
    //} catch(error) {}
  }



}

exports.Script = Script;